import pandas as pd
import numpy as np
from pathlib import Path
import warnings

warnings.filterwarnings('ignore')

# Config
DATA_DIR = Path("data/curated")
METRICS_DIR = Path("data/metrics")
FACT_FP = DATA_DIR / "factors_weekly_enhanced.parquet"
OUTPUT_IC_CSV = METRICS_DIR / "feature_rank_ic.csv"

def main():
    print(f"Loading features from {FACT_FP}...")
    df = pd.read_parquet(FACT_FP)
    
    # Ensure date is datetime
    df["date_week"] = pd.to_datetime(df["date_week"])
    
    # Identify feature columns (ending in _z)
    features = [c for c in df.columns if c.endswith("_z")]
    print(f"Found {len(features)} features: {features}")
    
    # Calculate Forward Return (Target)
    # ret_simple_weekly is the return for the week ending at date_week.
    # We want to predict the NEXT week's return using CURRENT week's features.
    # So for row at T, target is ret at T+1.
    print("Calculating forward returns...")
    df = df.sort_values(["symbol", "date_week"])
    df["y_fwd"] = df.groupby("symbol")["ret_simple_weekly"].shift(-1)
    
    # Drop NaNs in target
    df = df.dropna(subset=["y_fwd"])
    
    # Calculate Rank IC per week
    print("Calculating Rank IC per week...")
    ic_list = []
    
    # Group by week
    for date, group in df.groupby("date_week"):
        if len(group) < 10: # Skip weeks with too few assets
            continue
            
        # Rank the target
        # We want to see if Feature Rank correlates with Target Rank
        # Spearman correlation is Pearson on Ranks.
        
        # We can simply use corr(method='spearman')
        # Select features + target
        cols = features + ["y_fwd"]
        # Drop rows where any feature is nan (optional, or per pair)
        # Using corr() handles nans pair-wise usually, but let's be safe
        sub = group[cols]
        
        # Calculate Spearman correlation of features vs y_fwd
        corr = sub.corr(method="spearman")["y_fwd"].drop("y_fwd")
        
        corr_dict = corr.to_dict()
        corr_dict["date_week"] = date
        ic_list.append(corr_dict)
        
    ic_df = pd.DataFrame(ic_list).set_index("date_week")
    
    # Calculate Mean IC, ICIR (Mean / Std)
    summary = []
    for feat in features:
        if feat in ic_df.columns:
            mean_ic = ic_df[feat].mean()
            std_ic = ic_df[feat].std()
            icir = mean_ic / std_ic if std_ic > 1e-9 else 0.0
            summary.append({
                "Feature": feat,
                "Rank_IC": mean_ic,
                "ICIR": icir,
                "Hit_Rate": (ic_df[feat] > 0).mean()
            })
            
    summary_df = pd.DataFrame(summary).sort_values("Rank_IC", ascending=False)
    
    print("\n--- Feature Rank IC Summary ---")
    print(summary_df)
    
    # Save
    # Save
    print(f"\nSaving Rank IC summary to {OUTPUT_IC_CSV}...")
    summary_df.to_csv(OUTPUT_IC_CSV, index=False)
    
    # Save Time Series IC
    ic_ts_fp = METRICS_DIR / "feature_rank_ic_ts.csv"
    print(f"Saving Time Series IC to {ic_ts_fp}...")
    ic_df.to_csv(ic_ts_fp)

    # Visualization
    import matplotlib.pyplot as plt
    import seaborn as sns

    # 1. Bar Chart of Mean Rank IC
    plt.figure(figsize=(10, 8))
    sns.barplot(data=summary_df, x="Rank_IC", y="Feature", palette="viridis")
    plt.title("Mean Rank IC by Feature")
    plt.xlabel("Mean Rank IC")
    plt.tight_layout()
    plt.savefig(METRICS_DIR / "feature_ic_bar.png")
    plt.close()
    print(f"Saved feature_ic_bar.png to {METRICS_DIR}")

    # 2. Cumulative IC Plot
    # Identify top 5 and bottom 5 features by absolute IC to plot
    top_features = summary_df.head(5)["Feature"].tolist()
    # bot_features = summary_df.tail(5)["Feature"].tolist()
    # plot_feats = list(set(top_features + bot_features))
    plot_feats = top_features # Just top 5 for clarity

    plt.figure(figsize=(12, 6))
    for feat in plot_feats:
        if feat in ic_df.columns:
            cum_ic = ic_df[feat].cumsum()
            plt.plot(cum_ic.index, cum_ic, label=feat)
    
    plt.title("Cumulative Rank IC (Top 5 Features)")
    plt.xlabel("Date")
    plt.ylabel("Cumulative IC")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(METRICS_DIR / "feature_ic_cumulative.png")
    plt.close()
    print(f"Saved feature_ic_cumulative.png to {METRICS_DIR}")

    # 3. IC Heatmap (Time vs Feature)
    # Resample to Monthly for cleaner heatmap if too long, but weekly is fine for vertical
    plt.figure(figsize=(12, 10))
    # Transpose for Feature on Y, Time on X
    sns.heatmap(ic_df[features].T, cmap="coolwarm", center=0, cbar_kws={'label': 'Rank IC'})
    plt.title("Rank IC Heatmap (Weekly)")
    plt.xlabel("Date")
    plt.tight_layout()
    plt.savefig(METRICS_DIR / "feature_ic_heatmap.png")
    plt.close()
    print(f"Saved feature_ic_heatmap.png to {METRICS_DIR}")

    print("Done.")

if __name__ == "__main__":
    main()
