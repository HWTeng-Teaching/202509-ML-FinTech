
import pandas as pd
from pathlib import Path

FMP_FP = Path("/Users/sammm/Documents/HW_code/Fintech_ML/ml-crypto/data/curated/fmp_weekly.parquet")

if FMP_FP.exists():
    df = pd.read_parquet(FMP_FP)
    df["date_week"] = pd.to_datetime(df["date_week"])
    
    # Filter for 2022-2023
    mask = (df["date_week"] >= "2022-01-01") & (df["date_week"] <= "2023-12-31")
    subset = df.loc[mask, ["date_week", "BTC", "CMKT"]].sort_values("date_week")
    
    print("Shape:", subset.shape)
    print(subset.head(10))
    print(subset.tail(10))
    print("\nDescriptive Stats for BTC returns in 2022-2023:")
    print(subset["BTC"].describe())
    
    # Check for zeros or NaNs
    print("\nZeros/NaNs:")
    print((subset["BTC"] == 0).sum(), "zeros")
    print(subset["BTC"].isna().sum(), "NaNs")
else:
    print("File not found")
