
import pandas as pd
from pathlib import Path

path = Path("/Users/sammm/Documents/HW_code/Fintech_ML/ml-crypto/data/curated/factors_weekly.parquet")
df = pd.read_parquet(path)
print("Columns in factors_weekly.parquet:")
for c in df.columns:
    print(c)
