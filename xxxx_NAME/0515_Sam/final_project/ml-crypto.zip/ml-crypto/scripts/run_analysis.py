import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import json
from pathlib import Path

# Settings
plt.style.use('ggplot')
pd.set_option('display.max_rows', 100)

# Paths
ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data/curated"
METRICS_DIR = ROOT / "data/metrics"
METRICS_DIR.mkdir(parents=True, exist_ok=True)

IMP_FP = METRICS_DIR / "feature_importance_enhanced.csv"
BT_FP = DATA_DIR / "backtest_ml_longshort_enhanced.parquet"
SUM_FP = METRICS_DIR / "backtest_summary_enhanced.json"
BTC_FP = DATA_DIR / "btc_benchmark.parquet"

def plot_feature_importance():
    print("Plotting Feature Importance...")
    if IMP_FP.exists():
        imp = pd.read_csv(IMP_FP)
        print("Feature Importance Loaded. Shape:", imp.shape)
        
        # Sort and Plot Top 20
        imp = imp.sort_values("importance", ascending=True).tail(20)
        
        plt.figure(figsize=(10, 8))
        plt.barh(imp["feature"], imp["importance"], color="skyblue")
        plt.title("Top 20 Feature Importance (LightGBM Gain)")
        plt.xlabel("Gain Importance")
        plt.tight_layout()
        plt.savefig(METRICS_DIR / "feature_importance.png")
        print(f"Saved feature_importance.png to {METRICS_DIR}")
        plt.close()
    else:
        print(f"Feature importance file not found at {IMP_FP}")

def print_summary():
    print("\nBacktest Summary:")
    if SUM_FP.exists():
        with open(SUM_FP, "r") as f:
            summary = json.load(f)
        
        for k, v in summary.items():
            if isinstance(v, float):
                print(f"{k}: {v:.4f}")
            else:
                print(f"{k}: {v}")
    else:
        print(f"Backtest summary not found at {SUM_FP}")

def plot_equity_curve():
    print("\nPlotting Equity Curve...")
    # Load Backtest Data
    if BT_FP.exists():
        bt = pd.read_parquet(BT_FP)
        bt["date_week"] = pd.to_datetime(bt["date_week"])
        bt = bt.sort_values("date_week")
        print(f"Backtest data loaded: {len(bt)} weeks from {bt['date_week'].min().date()} to {bt['date_week'].max().date()}")
    else:
        print("Backtest data not found.")
        return

    # Load Market Data (BTC Benchmark)
    if BTC_FP.exists():
        bench = pd.read_parquet(BTC_FP)
        bench["date_week"] = pd.to_datetime(bench["date_week"])
        
        if "BTC_ret" in bench.columns:
            bench = bench.rename(columns={"BTC_ret": "ret_bench"})
        
        if "ret_bench" in bench.columns:
            bench = bench[["date_week", "ret_bench"]].dropna()
            # Ensure timezone-naive for merging
            bench["date_week"] = bench["date_week"].dt.tz_localize(None)
            print(f"Benchmark loaded: {len(bench)} weeks.")
        else:
            print("Benchmark column 'ret_bench' or 'BTC_ret' not found.")
            bench = pd.DataFrame()
    else:
        print(f"Benchmark file not found at {BTC_FP}")
        bench = pd.DataFrame()

    # Merge
    if not bench.empty:
        df = pd.merge(bt, bench, on="date_week", how="inner")
    else:
        df = bt.copy()
        df["ret_bench"] = 0.0
    
    print(f"Merged data: {len(df)} weeks")

    # Cumulative    # 计算累计收益
    # Strategy return: use 'ret_net_vt' (vol-targeted net return)
    df["cum_ret_strat"] = (1 + df["ret_net_vt"]).cumprod()
    df["cum_ret_bench"] = (1 + df["ret_bench"]).cumprod()

    # Plot Equity Curve
    plt.figure(figsize=(12, 6))
    plt.plot(df["date_week"], df["cum_ret_strat"], label="Enhanced ML Strategy (Beta Neutral)", linewidth=2, color="blue")
    plt.plot(df["date_week"], df["cum_ret_bench"], label="BTC Benchmark", linewidth=2, color="gray", alpha=0.7)
    
    plt.title("Cumulative Returns: Strategy vs BTC")
    plt.yscale("log")
    plt.grid(True, which="both", linestyle="--", alpha=0.5)
    plt.legend()
    plt.ylabel("Cumulative Return (Log Scale)")
    plt.tight_layout()
    plt.savefig(METRICS_DIR / "equity_curve_log.png")
    print(f"Saved equity_curve_log.png to {METRICS_DIR}")
    plt.close()

    # Plot Drawdown
    df["peak_strat"] = df["cum_ret_strat"].cummax()
    df["dd_strat"] = (df["cum_ret_strat"] / df["peak_strat"]) - 1
    
    df["peak_bench"] = df["cum_ret_bench"].cummax()
    df["dd_bench"] = (df["cum_ret_bench"] / df["peak_bench"]) - 1

    plt.figure(figsize=(12, 4))
    plt.plot(df["date_week"], df["dd_strat"], label="Strategy Drawdown", color="red", alpha=0.7)
    plt.plot(df["date_week"], df["dd_bench"], label="BTC Drawdown", color="gray", alpha=0.3)
    plt.fill_between(df["date_week"], df["dd_strat"], 0, color="red", alpha=0.1)
    
    plt.title("Drawdown Analysis")
    plt.ylabel("Drawdown")
    plt.legend()
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    plt.savefig(METRICS_DIR / "drawdown.png")
    print(f"Saved drawdown.png to {METRICS_DIR}")
    plt.close()

if __name__ == "__main__":
    plot_feature_importance()
    print_summary()
    plot_equity_curve()
