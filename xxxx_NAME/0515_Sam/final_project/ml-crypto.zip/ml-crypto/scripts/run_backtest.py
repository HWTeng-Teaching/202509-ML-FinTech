
import pandas as pd
import numpy as np
import json
from pathlib import Path
import warnings

warnings.filterwarnings('ignore')

# Config
DATA_DIR = Path("/Users/sammm/Documents/HW_code/Fintech_ML/ml-crypto/data/curated")
METRICS_DIR = Path("/Users/sammm/Documents/HW_code/Fintech_ML/ml-crypto/data/metrics")
PRED_FP = DATA_DIR / "ml_preds_weekly.parquet"
FACT_FP = DATA_DIR / "factors_weekly.parquet"
FMP_FP = DATA_DIR / "fmp_weekly.parquet"
OUTPUT_BACKTEST = DATA_DIR / "backtest_ml_longshort_enhanced.parquet"
OUTPUT_SUMMARY = METRICS_DIR / "backtest_summary_enhanced.json"

# Parameters
PARAMS = dict(
    Q=5,                        
    GROSS_LEV=1.0,              
    MAX_W_PER_ASSET=0.10,       
    TC_BPS=10,                  
    MAX_TURNOVER_ASSET=0.30,    
    VOL_TARGET_ANN=0.30,        
    VOL_ROLL_WEEKS=26,          
    BETA_ROLL_WEEKS=52,         
    BETA_NEUTRAL=True,  # Enable Beta Neutral to reduce market risk
    # Plan said "Validate Beta Neutrality effectiveness". Let's run with True first to compare with baseline.
    VOL_TARGET=True             
)

# Helper functions
def rolling_beta_to_cmkt(df_one: pd.DataFrame, win: int, cmkt: pd.DataFrame) -> pd.DataFrame:
    out = []
    g = df_one.merge(cmkt, on="date_week", how="left").dropna(subset=["ret","CMKT"]).copy()
    for i in range(win, len(g)+1):
        sub = g.iloc[i-win:i]
        x = sub["CMKT"].values
        y = sub["ret"].values
        X = np.vstack([np.ones_like(x), x]).T
        try:
            b = np.linalg.lstsq(X, y, rcond=None)[0][1]
        except Exception:
            b = np.nan
        out.append({"date_week": sub["date_week"].iloc[-1], "beta_cmkt": b})
    return pd.DataFrame(out)

def beta_neutralize(w: pd.Series, beta: pd.Series) -> pd.Series:
    beta = beta.reindex(w.index).fillna(0.0)
    num = float((w * beta).sum())
    den = float((beta ** 2).sum())
    if den <= 1e-12:
        return w
    lam = num / den
    return w - lam * beta

def apply_turnover_cap(w_prev: pd.Series, w_target: pd.Series, cap: float) -> pd.Series:
    w_prev = w_prev.reindex(w_target.index).fillna(0.0)
    delta = (w_target - w_prev).clip(-cap, cap)
    return w_prev + delta, delta

def sharpe_annual(weekly_ret: pd.Series) -> float:
    mu = weekly_ret.mean() * 52
    sd = weekly_ret.std() * np.sqrt(52)
    return float(mu / sd) if sd > 1e-12 else np.nan

def max_drawdown(cum: pd.Series) -> float:
    peak = cum.cummax()
    dd = (cum/peak - 1.0)
    return float(dd.min())

def summarize_bt(df: pd.DataFrame, col: str = "ret_net_vt") -> pd.Series:
    s = {}
    s["weeks"]        = int(len(df))
    s["ann_return"]   = df[col].mean() * 52
    s["ann_vol"]      = df[col].std() * np.sqrt(52)
    s["sharpe"]       = sharpe_annual(df[col])
    s["mdd"]          = max_drawdown((1 + df[col]).cumprod())
    s["avg_turnover"] = df["turnover"].mean()
    s["avg_tc_bps"]   = df["tc"].mean() * 1e4
    s["beta_cmkt"]    = df["beta_cmkt_port"].mean() if "beta_cmkt_port" in df.columns else np.nan
    return pd.Series(s)

def backtest_from_pred(pred_df, params, asset_key, beta_df=None, cmkt_df=None):
    Q = params["Q"]; GROSS = params["GROSS_LEV"]; MAX_W = params["MAX_W_PER_ASSET"]
    TC_BPS = params["TC_BPS"]; MAX_TO = params["MAX_TURNOVER_ASSET"]
    VOL_TGT = params["VOL_TARGET_ANN"]; VOL_WIN = params["VOL_ROLL_WEEKS"]
    DO_BETA = params["BETA_NEUTRAL"]; DO_VT = params["VOL_TARGET"]

    all_dates = sorted(pred_df["date_week"].unique())
    w_prev = pd.Series(dtype=float)
    rows = []

    for d in all_dates:
        g = pred_df[pred_df["date_week"] == d].dropna(subset=["y_pred","ret"]).copy()
        if len(g) < 10:
            continue

        try:
            q = pd.qcut(g["y_pred"], Q, labels=False, duplicates="drop")
        except Exception:
            rk = g["y_pred"].rank(method="average", pct=True)
            q = np.floor(rk * Q).clip(0, Q-1).astype(int)

        g = g.assign(bucket=q)
        # Inverted Logic Test
        long  = g[g["bucket"] == g["bucket"].min()]
        short = g[g["bucket"] == g["bucket"].max()]
        if len(long) == 0 or len(short) == 0:
            continue

        w_long  = pd.Series(GROSS/2 / len(long), index=long[asset_key])
        w_short = pd.Series(-GROSS/2 / len(short), index=short[asset_key])
        w = pd.concat([w_long, w_short]).groupby(level=0).sum()
        w = w.clip(-MAX_W, MAX_W)

        if DO_BETA and beta_df is not None and not beta_df.empty:
            beta_now = beta_df[beta_df["date_week"] == d].set_index(asset_key)["beta_cmkt"]
            w = beta_neutralize(w, beta_now)

        gross = w.abs().sum()
        if gross > 1e-12:
            w = w * (GROSS / gross)

        w, delta = apply_turnover_cap(w_prev.reindex(w.index).fillna(0.0), w, MAX_TO)

        gross = w.abs().sum()
        if gross > 1e-12:
            w = w * (GROSS / gross)

        tc = float(delta.abs().sum()) * (TC_BPS / 1e4)

        r = g.set_index(asset_key)["ret"].reindex(w.index).fillna(0.0)
        ret_gross = float((w * r).sum())
        ret_net   = ret_gross - tc

        beta_port = np.nan
        if DO_BETA and beta_df is not None and not beta_df.empty:
            beta_now = beta_df[beta_df["date_week"] == d].set_index(asset_key)["beta_cmkt"].reindex(w.index)
            beta_port = float((w * beta_now.fillna(0.0)).sum())

        rows.append({
            "date_week": d,
            "ret_gross": ret_gross,
            "ret_net": ret_net,
            "turnover": float(delta.abs().sum()),
            "tc": tc,
            "n_long": int((w>0).sum()),
            "n_short": int((w<0).sum()),
            "beta_cmkt_port": beta_port
        })

        w_prev = w.copy()

    port = pd.DataFrame(rows).sort_values("date_week").reset_index(drop=True)

    if DO_VT and not port.empty:
        target_sigma_w = VOL_TGT / np.sqrt(52)
        port["vol_scale"] = 1.0
        for i in range(VOL_WIN, len(port)):
            sigma = port["ret_net"].iloc[i-VOL_WIN:i].std()
            if pd.notna(sigma) and sigma > 1e-8:
                scale = target_sigma_w / sigma
                scale = float(np.clip(scale, 0.5, 2.0))
            else:
                scale = 1.0
            port.loc[i, "vol_scale"] = scale
        port["ret_net_vt"] = port["ret_net"] * port["vol_scale"]
    else:
        port["vol_scale"] = 1.0
        port["ret_net_vt"] = port["ret_net"]

    return port

def main():
    print(f"Loading predictions from {PRED_FP}...")
    if not PRED_FP.exists():
        print("Predictions file not found!")
        return
        
    pred = pd.read_parquet(PRED_FP)
    pred["date_week"] = pd.to_datetime(pred["date_week"])
    
    print(f"Loading factors from {FACT_FP}...")
    fact = pd.read_parquet(FACT_FP)
    fact["date_week"] = pd.to_datetime(fact["date_week"])
    if "rf_weekly" not in fact.columns:
        fact["rf_weekly"] = 0.0

    print(f"Loading market factor from {FMP_FP}...")
    fmp = pd.read_parquet(FMP_FP)
    fmp["date_week"] = pd.to_datetime(fmp["date_week"])
    
    cmkt = fmp[["date_week", "CMKT"]].dropna()

    # Asset Keys
    asset_key = "symbol"
    for df in [pred, fact]:
        if "symbol" in df.columns:
            df["symbol"] = df["symbol"].astype(str).str.upper()

    # Merge
    cols_keep = ["date_week", asset_key, "ret_simple_weekly", "rf_weekly"]
    m = pred.merge(fact[cols_keep], on=["date_week", asset_key], how="left").rename(columns={"ret_simple_weekly": "ret"})
    m = m.sort_values([asset_key, "date_week"]).reset_index(drop=True)

    # Calculate Beta
    beta_df = pd.DataFrame()
    if PARAMS["BETA_NEUTRAL"]:
        print("Calculating rolling betas...")
        beta_list = []
        for aid, g in m.groupby(asset_key):
            rb = rolling_beta_to_cmkt(g[[asset_key, "date_week", "ret"]].copy(), PARAMS["BETA_ROLL_WEEKS"], cmkt)
            if not rb.empty:
                rb[asset_key] = aid
                beta_list.append(rb)
        if beta_list:
            beta_df = pd.concat(beta_list, ignore_index=True)

    # Run Backtest
    print("Running backtest...")
    port = backtest_from_pred(m, PARAMS, asset_key, beta_df, cmkt)
    
    if port.empty:
        print("Backtest returned empty portfolio!")
        return

    # Summary
    sum_stats = summarize_bt(port, col="ret_net_vt")
    print("\n--- Backtest Summary ---")
    print(sum_stats)
    
    # Save
    print(f"Saving backtest to {OUTPUT_BACKTEST}...")
    port.to_parquet(OUTPUT_BACKTEST)
    
    # Save summary json
    with open(OUTPUT_SUMMARY, 'w') as f:
        json.dump(sum_stats.to_dict(), f, indent=4)
        
    print("Done.")

if __name__ == "__main__":
    main()
