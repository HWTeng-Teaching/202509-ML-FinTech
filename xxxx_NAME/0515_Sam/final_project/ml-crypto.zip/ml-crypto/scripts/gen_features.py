
import pandas as pd
import numpy as np
from pathlib import Path

# Config
DATA_DIR = Path("/Users/sammm/Documents/HW_code/Fintech_ML/ml-crypto/data/curated")
INPUT_PRICES = DATA_DIR / "prices_weekly.parquet"
INPUT_FACTORS = DATA_DIR / "factors_weekly.parquet"
OUTPUT_FACTORS = DATA_DIR / "factors_weekly_enhanced.parquet"

def calculate_rsi(series, period=14):
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def calculate_atr(df, period=14):
    high = df['high']
    low = df['low']
    close = df['close']
    prev_close = close.shift(1)
    
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr = tr.rolling(window=period).mean()
    return atr

def calculate_bollinger_bands(series, period=20, num_std=2):
    rolling_mean = series.rolling(window=period).mean()
    rolling_std = series.rolling(window=period).std()
    upper = rolling_mean + (rolling_std * num_std)
    lower = rolling_mean - (rolling_std * num_std)
    # Band Width
    width = (upper - lower) / rolling_mean
    return width

def calculate_macd(series, fast=12, slow=26, signal=9):
    exp1 = series.ewm(span=fast, adjust=False).mean()
    exp2 = series.ewm(span=slow, adjust=False).mean()
    macd = exp1 - exp2
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    return macd - signal_line # Histogram

def main():
    print(f"Loading prices from {INPUT_PRICES}...")
    prices = pd.read_parquet(INPUT_PRICES)
    prices['date_week'] = pd.to_datetime(prices['date_week'])
    prices = prices.sort_values(['symbol', 'date_week'])
    
    print(f"Loading existing factors from {INPUT_FACTORS}...")
    factors = pd.read_parquet(INPUT_FACTORS)
    factors['date_week'] = pd.to_datetime(factors['date_week'])
    
    # Calculate Features per Symbol
    print("Calculating technical indicators...")
    
    # Group by symbol to calculate indicators
    # We use a wrapper function to apply to each group
    
    def calculate_group_features(group):
        # RSI
        group['RSI_14'] = calculate_rsi(group['close'], 14)
        
        # ATR / Close (Normalized ATR)
        # Note: prices weekly might not have perfect high/low for typical ATR if it's aggregated, 
        # but we use what we have. If weekly prices are just snapshots, we might need to be careful.
        # Assuming prices_weekly has OHLC for the week.
        if 'high' in group.columns and 'low' in group.columns:
            group['ATR_14'] = calculate_atr(group, 14)
            group['ATR_14_norm'] = group['ATR_14'] / group['close']
        
        # Bollinger Width
        group['BB_Width_20'] = calculate_bollinger_bands(group['close'], 20)
        
        # MACD
        group['MACD'] = calculate_macd(group['close'])
        
        # MA deviations
        group['Close_div_MA20'] = group['close'] / group['close'].rolling(window=20).mean()
        group['Close_div_MA50'] = group['close'] / group['close'].rolling(window=50).mean()
        
        # Rolling Volatility
        group['Vol_4w'] = group['close'].pct_change().rolling(window=4).std()
        group['Vol_12w'] = group['close'].pct_change().rolling(window=12).std()
        
        return group

    prices_enhanced = prices.groupby('symbol', group_keys=False).apply(calculate_group_features)
    
    # Select cols to merge
    new_cols = ['date_week', 'symbol', 'RSI_14', 'ATR_14_norm', 'BB_Width_20', 'MACD', 
                'Close_div_MA20', 'Close_div_MA50', 'Vol_4w', 'Vol_12w']
    
    # Filter only available columns (e.g. if ATR calculation failed)
    available_cols = [c for c in new_cols if c in prices_enhanced.columns]
    
    print(f"Merging with factors...")
    # Merge on date_week and symbol (or asset key if differing)
    # The existing factors df has 'symbol' and 'date_week'.
    
    # prices_enhanced might have NaNs from rolling windows, we keep them or fill?
    # Usually ML models handle them or we drop. Let's keep them and let training handle drop/fill.
    
    factors_enhanced = pd.merge(factors, prices_enhanced[available_cols], on=['date_week', 'symbol'], how='left')
    
    # Z-score normalization for new features per week (Cross-sectional)
    print("Calculating Z-scores...")
    z_score_cols = [c for c in available_cols if c not in ['date_week', 'symbol']]
    
    def z_score(x):
        return (x - x.mean()) / x.std()

    for col in z_score_cols:
        factors_enhanced[f"{col}_z"] = factors_enhanced.groupby('date_week')[col].transform(z_score)

    print(f"Saving enhanced factors to {OUTPUT_FACTORS}...")
    factors_enhanced.to_parquet(OUTPUT_FACTORS)
    print("Done.")
    print("New columns:", factors_enhanced.columns.tolist())

if __name__ == "__main__":
    main()
