import pandas as pd
import numpy as np
from pathlib import Path
import warnings

warnings.filterwarnings('ignore')

# Config
DATA_DIR = Path("data/curated")
METRICS_DIR = Path("data/metrics")
PRED_FP = DATA_DIR / "ml_preds_weekly.parquet"
OUTPUT_POS_CSV = METRICS_DIR / "weekly_positions.csv"

# Params (Must match run_backtest.py)
Q = 5
ASSET_KEY = "symbol"

def main():
    print(f"Loading predictions from {PRED_FP}...")
    if not PRED_FP.exists():
        print("Predictions file not found!")
        return
        
    pred = pd.read_parquet(PRED_FP)
    pred["date_week"] = pd.to_datetime(pred["date_week"])
    
    if ASSET_KEY not in pred.columns:
        # Fallback if symbol is not there (should differ based on prev steps)
        # Check columns
        if "market" in pred.columns and "symbol" not in pred.columns:
             pred["symbol"] = pred["market"].apply(lambda x: x.split("/")[0] if "/" in x else x)

    # Normalize symbol
    pred[ASSET_KEY] = pred[ASSET_KEY].astype(str).str.upper()

    all_dates = sorted(pred["date_week"].unique())
    rows = []

    print("Processing weekly positions...")
    for d in all_dates:
        g = pred[pred["date_week"] == d].dropna(subset=["y_pred"]).copy()
        if len(g) < 10:
            continue

        # Rank / Quantile
        try:
            q = pd.qcut(g["y_pred"], Q, labels=False, duplicates="drop")
        except Exception:
            rk = g["y_pred"].rank(method="average", pct=True)
            q = np.floor(rk * Q).clip(0, Q-1).astype(int)

        g = g.assign(bucket=q)
        
        # Inverted Logic from run_backtest.py:
        # long = bucket min (0)
        # short = bucket max (4)
        long_df  = g[g["bucket"] == g["bucket"].min()]
        short_df = g[g["bucket"] == g["bucket"].max()]
        
        long_assets = sorted(long_df[ASSET_KEY].unique().tolist())
        short_assets = sorted(short_df[ASSET_KEY].unique().tolist())
        
        rows.append({
            "date_week": d.strftime("%Y-%m-%d"),
            "long_assets": ",".join(long_assets),
            "short_assets": ",".join(short_assets),
            "n_long": len(long_assets),
            "n_short": len(short_assets)
        })
        
    out_df = pd.DataFrame(rows)
    print(f"\nGenerered position records for {len(out_df)} weeks.")
    print(out_df.tail())
    
    print(f"\nSaving positions list to {OUTPUT_POS_CSV}...")
    out_df.to_csv(OUTPUT_POS_CSV, index=False)
    print("Done.")

if __name__ == "__main__":
    main()
