
import pandas as pd
from pathlib import Path

path = Path("/Users/sammm/Documents/HW_code/Fintech_ML/ml-crypto/data/curated/prices_weekly.parquet")
df = pd.read_parquet(path)
print("Columns in prices_weekly.parquet:")
print(df.columns.tolist())
print(df.head())
