#!/usr/bin/env bash
set -euo pipefail

START_YEAR=${1:-2016}
END_YEAR=${2:-2024}
START_DATE=${3:-2016-01-01}
END_DATE=${4:-2025-12-31}

echo "[Step] Fetch CMC snapshots ${START_YEAR}-${END_YEAR}"
python src/data/fetch_cmc.py --start-year ${START_YEAR} --end-year ${END_YEAR}

echo "[Step] Build annual Top30 (ex-stablecoins)"
python src/data/build_universe.py

echo "[Step] Fetch Binance daily for universe ${START_DATE}..${END_DATE}"
python src/data/fetch_binance.py --universe data/curated/universe_top30_annual.parquet --start ${START_DATE} --end ${END_DATE}

echo "[Step] Fetch FRED 4W T-Bill"
python src/data/fetch_fred.py --start 2015-01-01 --end ${END_DATE}

echo "[Step] Weekly align all series"
python src/data/weekly_align.py

echo "[Step] QC report"
python src/data/qc.py

echo "[Done] Outputs in data/curated and data/metrics"
