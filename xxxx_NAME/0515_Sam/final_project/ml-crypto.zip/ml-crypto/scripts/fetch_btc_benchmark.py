import ccxt
import pandas as pd
import time
from pathlib import Path
from datetime import datetime, timezone

# Setup paths
ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data/curated"
DATA_DIR.mkdir(parents=True, exist_ok=True)
OUT_PATH = DATA_DIR / "btc_benchmark.parquet"

def fetch_btc_daily():
    print("Initializing Binance exchange...")
    exchange = ccxt.binance({"enableRateLimit": True})
    symbol = "BTC/USDT"
    
    # Start from 2017-01-01 to cover the required period
    start_str = "2017-01-01"
    start_ts = int(pd.Timestamp(start_str, tz="UTC").timestamp() * 1000)
    end_ts = int(pd.Timestamp.utcnow().timestamp() * 1000)
    
    all_ohlcv = []
    since = start_ts
    limit = 1000
    
    print(f"Fetching {symbol} daily data since {start_str}...")
    
    while True:
        try:
            ohlcv = exchange.fetch_ohlcv(symbol, timeframe="1d", since=since, limit=limit)
            if not ohlcv:
                break
            
            all_ohlcv.extend(ohlcv)
            last_ts = ohlcv[-1][0]
            next_since = last_ts + 1
            
            print(f"Fetched up to {pd.to_datetime(last_ts, unit='ms', utc=True).date()}")
            
            if next_since >= end_ts:
                break
                
            since = next_since
            time.sleep(0.5) # Be gentle with API
            
        except Exception as e:
            print(f"Error fetching data: {e}")
            time.sleep(5)
            continue

    if not all_ohlcv:
        print("No data fetched!")
        return

    # Convert to DataFrame
    df = pd.DataFrame(all_ohlcv, columns=["ts", "open", "high", "low", "close", "volume"])
    df["date"] = pd.to_datetime(df["ts"], unit="ms", utc=True).dt.tz_convert("UTC")
    
    # Resample to Weekly (Sunday)
    # Strategy likely uses Sunday-based weeks (or whatever fmp_weekly uses). 
    # Usually crypto factor data often aligns to Sunday 00:00 UTC or end of Sunday.
    # Let's check fmp_weekly alignment if possible, but standard is usually W-SUN.
    # We will compute weekly returns from daily close.
    
    df.set_index("date", inplace=True)
    df = df.sort_index()
    
    # Resample to weekly, taking the last close
    # 'W-SUN' ensures it ends on Sunday
    df_weekly = df['close'].resample('W-SUN').last().to_frame(name="BTC")
    
    # Calculate returns
    df_weekly["BTC_ret"] = df_weekly["BTC"].pct_change()
    
    # Reset index to have date_week column
    df_weekly = df_weekly.reset_index().rename(columns={"date": "date_week"})
    
    # Ensure date_week is just the date part (if that's what other files use)
    # But usually it's a Timestamp. Let's keep it as Timestamp for checking alignment.
    
    print(df_weekly.tail())
    print(f"Saving to {OUT_PATH}")
    df_weekly.to_parquet(OUT_PATH)
    print("Done.")

if __name__ == "__main__":
    fetch_btc_daily()
