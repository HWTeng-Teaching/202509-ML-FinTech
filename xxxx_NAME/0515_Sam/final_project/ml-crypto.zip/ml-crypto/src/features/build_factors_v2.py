#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Build feasible weekly factors aligned to:
- Liu et al. (2022, JF): Size / Momentum / Volume / Volatility
- Han et al. (2024): short-window risk-adjusted momentum (rmom3)

Inputs
------
- data/curated/prices_weekly.parquet   (from Step 1; Binance 或 CoinGecko 路徑皆可)
- data/curated/universe_top30_annual.parquet  (年末 CMC 快照聚成之年度宇宙，含 market_cap_usd)

Outputs
-------
- data/curated/factors_weekly.parquet

Notes
-----
- 市值以「年末快照 → 隔年固定」的方式當作 Size 因子代理：log_mcap_year
- Asset key 以 'market'（Binance）→ 'symbol' → 'coingecko_id' 優先
- 每週做 cross-section winsor(1%/99%) + z-score，輸出 *_z 欄位
"""

from pathlib import Path
import yaml
import numpy as np
import pandas as pd


# ---------------------------------------
# 基本設定與路徑
# ---------------------------------------
ROOT = Path(__file__).resolve().parents[2]
CFG = yaml.safe_load(open(ROOT / "config/data_sources.yaml"))
CUR = ROOT / CFG["io"]["curated_dir"]

ASSET_KEYS = ["market", "symbol", "coingecko_id"]  # 偵測資產識別欄位的優先序


def pick_key(df: pd.DataFrame) -> str | None:
    """依優先序挑選資產識別欄位（Binance: market / symbol；CoinGecko: coingecko_id）"""
    for k in ASSET_KEYS:
        if k in df.columns:
            return k
    return None


def winsorize(s: pd.Series, lo=0.01, hi=0.99) -> pd.Series:
    """分位點 winsor（週內橫截面）"""
    if s.dropna().empty:
        return s
    lo_v, hi_v = s.quantile(lo), s.quantile(hi)
    return s.clip(lo_v, hi_v)


def zscore(s: pd.Series) -> pd.Series:
    """z-score（週內橫截面）"""
    m, v = s.mean(), s.std(ddof=0)
    if v == 0 or np.isnan(v):
        return s * 0.0
    return (s - m) / v


def main():
    pw_path = CUR / "prices_weekly.parquet"
    uni_path = CUR / "universe_top30_annual.parquet"

    if not pw_path.exists():
        raise SystemExit(f"Missing {pw_path} — 請先完成 Step 1 的 weekly_align.py")
    if not uni_path.exists():
        raise SystemExit(f"Missing {uni_path} — 請先完成年度宇宙建置 build_universe.py")

    # 週資料（已含：date_week, open/high/low/close/volume, ret_simple_weekly, [rf_weekly?], [market/symbol/coingecko_id]）
    pw = pd.read_parquet(pw_path)
    key = pick_key(pw)
    if key is None:
        pw["_asset"] = "asset_0"
        key = "_asset"

    pw["date_week"] = pd.to_datetime(pw["date_week"])
    pw["year"] = pw["date_week"].dt.year

    # 年度宇宙（含 CMC 年末市值）→ 對應隔年使用（建宇宙時已處理 year = snapshot_year + 1）
    uni = pd.read_parquet(uni_path)

    # 若具 symbol，將年度市值對上來（作 size 因子代理）
    if "symbol" in pw.columns:
        u = uni[["year", "symbol", "market_cap_usd"]].copy()
        u["symbol"] = u["symbol"].astype(str).str.upper()
        pw["symbol"] = pw["symbol"].astype(str).str.upper()
        pw = pw.merge(u, on=["year", "symbol"], how="left")
        # log 市值（0 或缺值時為 NaN）
        pw["log_mcap_year"] = np.log(pw["market_cap_usd"].replace({0: np.nan}))
    else:
        pw["log_mcap_year"] = np.nan

    # 近似美元成交額（USDT/USDC 對下 close ≈ USD）：price × volume
    pw["prcvol"] = pw["close"] * pw["volume"]

    # 依資產做時間序計算
    pw = pw.sort_values([key, "date_week"]).copy()

    def roll(g: pd.DataFrame) -> pd.DataFrame:
        """依資產計算週度動量/波動/量價因子"""
        g = g.sort_values("date_week").copy()
        r = g["ret_simple_weekly"]

        # Momentum：r1..r4（滾動累積，排除當週），r4_1 = (t-4..t-1) 累積
        # r1：上週收益
        g["r1"] = r.shift(1)

        # r2..r4：過去 2~4 週的累積報酬（不含當週）
        def cum_k(k: int):
            # 使用 (1+r_{t-1})...(1+r_{t-k}) - 1
            return (1.0 + r.shift(1)).rolling(k).apply(
                lambda x: np.prod(x) - 1 if len(x) == k else np.nan, raw=False
            )

        g["r2"] = cum_k(2)
        g["r3"] = cum_k(3)
        g["r4"] = cum_k(4)
        g["r4_1"] = cum_k(4)  # 與上式相同語意，單獨保留字段以便清楚對應文獻

        # Han et al. (2024) 推薦的短窗風險調整動能：近 3 週 Sharpe（以上週起算）
        g["rmom3"] = r.shift(1).rolling(3).mean() / r.shift(1).rolling(3).std()

        # Volatility：近 4 週收益標準差
        g["vol_4w"] = r.rolling(4).std()

        # Volume / Liquidity：prcvol 的 4 週均值 / 標準差
        g["prcvol_mean_week"] = g["prcvol"].rolling(4).mean()
        g["prcvol_std_week"] = g["prcvol"].rolling(4).std()

        # Size / Price Level：末週價格對數、當週最高價（weekly_align 已是週內 high 的 max）
        g["log_price"] = np.log1p(g["close"])
        g["max_price_week"] = g["high"]

        return g

    pw = pw.groupby(key, group_keys=False).apply(roll)

    # 週內 cross-section winsor + z-score
    base_factors = [
        "log_mcap_year",      # Size
        "log_price",
        "max_price_week",
        "r1", "r2", "r3", "r4", "r4_1",  # Momentum
        "rmom3",
        "prcvol_mean_week",   # Volume/Liquidity
        "prcvol_std_week",
        "vol_4w",             # Volatility
    ]

    def cs(g: pd.DataFrame) -> pd.DataFrame:
        g = g.copy()
        for c in base_factors:
            x = g[c].astype(float)
            xw = winsorize(x)
            g[c + "_z"] = zscore(xw)
        return g

    pw = pw.groupby("date_week", group_keys=False).apply(cs)

    # 輸出欄位
    keep = [
        "date_week",
        key,
        "symbol" if "symbol" in pw.columns else None,
        "close",
        "ret_simple_weekly",
    ] + base_factors + [c + "_z" for c in base_factors]
    keep = [c for c in keep if c is not None]

    out = pw[keep].dropna(subset=["ret_simple_weekly"])
    out_path = CUR / "factors_weekly.parquet"
    out.to_parquet(out_path, index=False)

    n_assets = out["symbol"].nunique() if "symbol" in out.columns else out[key].nunique()
    print(f"[ok] wrote {out_path} with {len(out):,} rows; assets={n_assets}")


if __name__ == "__main__":
    main()
