#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Build factor-mimicking portfolios (weekly, hold 1 week):
- CMKT: equal-weight market return (next-week)
- CSMB: size factor (Big − Small), sort by log_mcap_year_z at t, hold at t+1
- CMOM: momentum factor (Winners − Losers), sort by r4_1_z at t, hold at t+1

Input
-----
data/curated/factors_weekly.parquet
  必含欄位：
    - date_week, ret_simple_weekly
    - 以及資產識別欄位之一：market（Binance）/ symbol / coingecko_id
  推薦（若無則自動回退）：
    - log_mcap_year_z（若無，退回 log_mcap_year）
    - r4_1_z（若無，退回 r4_1）

Output
------
data/curated/fmp_weekly.parquet  (columns: date_week, CMKT, CSMB, CMOM)
"""

from pathlib import Path
import yaml
import numpy as np
import pandas as pd

# ---------------- paths ----------------
ROOT = Path(__file__).resolve().parents[2]
CFG = yaml.safe_load(open(ROOT / "config/data_sources.yaml"))
CUR = ROOT / CFG["io"]["curated_dir"]

ASSET_KEYS = ["market", "symbol", "coingecko_id"]  # priority


def pick_key(df: pd.DataFrame) -> str:
    for k in ASSET_KEYS:
        if k in df.columns:
            return k
    df["_asset"] = "asset_0"
    return "_asset"


def long_short_spread(g: pd.DataFrame, score_col: str, ret_col: str, q: int = 5) -> float:
    """等權 Q_high − Q_low 的下週收益，分位於 t、持有 t+1。"""
    g = g.dropna(subset=[score_col, ret_col]).copy()
    if len(g) < q * 3:  # 樣本太少時跳過
        return np.nan
    try:
        g["bucket"] = pd.qcut(g[score_col], q, labels=False, duplicates="drop")
    except Exception:
        return np.nan
    lo = g[g["bucket"] == g["bucket"].min()][ret_col].mean()
    hi = g[g["bucket"] == g["bucket"].max()][ret_col].mean()
    return float(hi - lo)


def main():
    fp = CUR / "factors_weekly.parquet"
    if not fp.exists():
        raise SystemExit(f"Missing {fp}. 請先執行 build_factors_v2.py")

    df = pd.read_parquet(fp)
    df["date_week"] = pd.to_datetime(df["date_week"])
    key = pick_key(df)

    # 以「下週」報酬作為持有期報酬
    df = df.sort_values([key, "date_week"]).copy()
    df["ret_fwd1"] = df.groupby(key)["ret_simple_weekly"].shift(-1)

    # 市場組合（等權）
    cmkt = (
        df.groupby("date_week")["ret_fwd1"]
        .mean()
        .to_frame("CMKT")
        .reset_index()
    )

    # 分位用的分數欄位（沒有 z 就退回 base）
    size_col = "log_mcap_year_z" if "log_mcap_year_z" in df.columns else "log_mcap_year"
    mom_col = "r4_1_z" if "r4_1_z" in df.columns else "r4_1"

    # 逐週計算 CSMB / CMOM
    rows = []
    for d, g in df.groupby("date_week"):
        rows.append(
            {
                "date_week": d,
                "CSMB": long_short_spread(g, size_col, "ret_fwd1", q=5),
                "CMOM": long_short_spread(g, mom_col, "ret_fwd1", q=5),
            }
        )
    fmp = pd.DataFrame(rows)

    # 併上 CMKT
    fmp = fmp.merge(cmkt, on="date_week", how="outer")
    fmp = fmp[["date_week", "CMKT", "CSMB", "CMOM"]].sort_values("date_week")
    fmp = fmp.dropna(how="all", subset=["CMKT", "CSMB", "CMOM"])  # 全缺者移除
    fmp["data_version"] = pd.Timestamp.utcnow().strftime("%Y%m%d-%H%M")

    out = CUR / "fmp_weekly.parquet"
    fmp.to_parquet(out, index=False)
    print(f"[ok] wrote {out} — weeks={len(fmp)}, "
          f"CMKT_na={fmp['CMKT'].isna().sum()}, "
          f"CSMB_na={fmp['CSMB'].isna().sum()}, "
          f"CMOM_na={fmp['CMOM'].isna().sum()}")

if __name__ == "__main__":
    main()
