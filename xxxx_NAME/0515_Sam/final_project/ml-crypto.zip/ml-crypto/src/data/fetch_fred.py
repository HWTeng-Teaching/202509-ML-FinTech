#!/usr/bin/env python
"""
Fetch 4-week T-Bill (DTB4WK) from FRED, robust CSV parsing.
Saves: data/curated/rf_weekly.parquet with columns [date_week, rf_weekly]
"""
import argparse, os, io, yaml
from pathlib import Path
import pandas as pd
import requests

ROOT = Path(__file__).resolve().parents[2]
CFG = yaml.safe_load(open(ROOT/"config/data_sources.yaml"))
CUR = ROOT/CFG["io"]["curated_dir"]

SERIES = CFG["risk_free"]["fred_series"]
BOUNDARY = CFG["risk_free"]["weekly_boundary"]

def fetch_with_fredapi(series: str, start: str, end: str) -> pd.DataFrame | None:
    try:
        from fredapi import Fred
    except ImportError:
        return None
    key = os.getenv("FRED_API_KEY")
    if not key:
        return None
    fred = Fred(api_key=key)
    s = fred.get_series(series, observation_start=start, observation_end=end)
    df = s.to_frame(name="rate").reset_index().rename(columns={"index":"date"})
    return df

def fetch_csv_flex(series: str, start: str, end: str) -> pd.DataFrame:
    url = f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={series}"
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    df = pd.read_csv(io.StringIO(r.text))
    # normalize column names to lower
    df.columns = [c.lower() for c in df.columns]
    # possible date columns
    date_col = None
    for c in ["date","observation_date"]:
        if c in df.columns:
            date_col = c; break
    if date_col is None:
        # try first column as date
        date_col = df.columns[0]
    val_col = None
    for c in [series.lower(), "value", "rate"]:
        if c in df.columns:
            val_col = c; break
    if val_col is None:
        # try last column as value
        val_col = df.columns[-1]
    out = df[[date_col, val_col]].rename(columns={date_col:"date", val_col:"rate"})
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    out = out.dropna(subset=["date"])
    return out

def to_weekly(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["rate"] = pd.to_numeric(df["rate"], errors="coerce")/100.0
    df = df.dropna(subset=["rate"])
    df = df.set_index("date").sort_index()
    wf = df["rate"].resample("W-"+BOUNDARY).last().to_frame("rate_week")
    wf["rf_weekly"] = wf["rate_week"] * (28/365)
    wf = wf[["rf_weekly"]].reset_index().rename(columns={"date":"date_week"})
    wf["data_version"]=pd.Timestamp.utcnow().strftime("%Y%m%d-%H%M")
    return wf

def main(start, end):
    CUR.mkdir(parents=True, exist_ok=True)
    df = fetch_with_fredapi(SERIES, start, end)
    if df is None:
        df = fetch_csv_flex(SERIES, start, end)
    weekly = to_weekly(df)
    out = CUR/"rf_weekly.parquet"
    weekly.to_parquet(out, index=False)
    print(f"[ok] wrote {out} ({len(weekly)} rows)")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=str, default=None)
    ap.add_argument("--end", type=str, default=None)
    args = ap.parse_args()
    main(args.start, args.end)
