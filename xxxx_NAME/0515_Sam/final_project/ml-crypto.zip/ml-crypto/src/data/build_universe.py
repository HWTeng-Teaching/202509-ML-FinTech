#!/usr/bin/env python
"""
Build annual Top30 universe from CMC snapshots (last Sunday of each December).
Exclude stablecoins; save to curated/universe_top30_annual.parquet

Notes:
- Annual membership minimizes turnover and transaction costs while aligning with literature practice.
- Stablecoin removal by (i) explicit symbol list and (ii) low-volatility heuristic (checked later).
"""
import os, sys, re, glob, yaml, math, datetime as dt
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
CFG = yaml.safe_load(open(ROOT/"config/data_sources.yaml"))
UNI_CFG = yaml.safe_load(open(ROOT/"config/universe.yaml"))
RAW = ROOT/CFG["io"]["raw_dir"]/"cmc"
CUR = ROOT/CFG["io"]["curated_dir"]
CUR.mkdir(parents=True, exist_ok=True)

STABLE = set(CFG["stablecoins"]["symbols"])
overrides_ex = set(UNI_CFG.get("manual_overrides", {}).get("exclude_symbols", []) )
symbol2cg = UNI_CFG.get("symbol_to_coingecko_id", {})

def load_snapshots() -> pd.DataFrame:
    dfs = []
    for fp in sorted(glob.glob(str(RAW/"*"/"snapshot_*.parquet"))):
        df = pd.read_parquet(fp)
        df["snapshot_year"] = pd.to_datetime(df["snapshot_date"]).dt.year
        dfs.append(df)
    if not dfs:
        raise SystemExit("No snapshots found; run fetch_cmc.py first.")
    return pd.concat(dfs, ignore_index=True)

def assign_top30(df: pd.DataFrame) -> pd.DataFrame:
    out_rows = []
    for y, g in df.groupby("snapshot_year"):
        gg = g.sort_values("rank").head(60).copy()  # keep extra in case of exclusions
        gg["is_stablecoin"] = gg["symbol"].isin(STABLE)
        gg = gg[~gg["symbol"].isin(overrides_ex)]
        gg = gg[~gg["is_stablecoin"]]
        gg = gg.sort_values("rank").head(30).copy()
        gg["rank_top30"] = range(1, len(gg)+1)
        gg["year"] = y + 1  # membership for the *next* calendar year
        out_rows.append(gg[["year","rank_top30","name","symbol","slug","market_cap_usd"]])
    uni = pd.concat(out_rows, ignore_index=True)
    # attach (tentative) CoinGecko ids via a heuristic; user can fix in config/universe.yaml
    def guess_cg_id(name, symbol, slug):
        key = symbol2cg.get(symbol)
        if key: return key
        # heuristic: prefer slug if it looks like coingecko id (often the same)
        if isinstance(slug, str):
            return slug.lower()
        return name.lower().replace(" ", "-")
    uni["coingecko_id_guess"] = uni.apply(lambda r: guess_cg_id(r["name"], r["symbol"], r["slug"]), axis=1)
    uni["data_version"] = pd.Timestamp.utcnow().strftime("%Y%m%d-%H%M")
    return uni

def main():
    df = load_snapshots()
    uni = assign_top30(df)
    out = CUR/"universe_top30_annual.parquet"
    uni.to_parquet(out, index=False)
    print(f"[ok] wrote {out}")

if __name__ == "__main__":
    main()
