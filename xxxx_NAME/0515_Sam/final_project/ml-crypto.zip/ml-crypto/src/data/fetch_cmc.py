#!/usr/bin/env python
"""
Robust CMC historical snapshot fetcher.

Strategy (for each snapshot date):
1) Try live CMC: https://coinmarketcap.com/historical/YYYYMMDD/
   - Parse either <table> or data-rows containers.
2) If not found, fall back to Wayback:
   https://web.archive.org/web/YYYYMMDD/https://coinmarketcap.com/historical/YYYYMMDD/
3) If still not found, raise a clear error with suggestions.

Outputs: data/raw/cmc/{year}/snapshot_YYYYMMDD.parquet
"""

import argparse, time, re, datetime as dt
from pathlib import Path
import requests
from bs4 import BeautifulSoup
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[2]
CFG = yaml.safe_load(open(ROOT/"config/data_sources.yaml"))
RAW_DIR = ROOT/CFG["io"]["raw_dir"]/"cmc"

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

def last_sunday_of_dec(year: int) -> dt.date:
    d = dt.date(year, 12, 31)
    while d.weekday() != 6:  # Sunday = 6
        d -= dt.timedelta(days=1)
    return d

def _http_get(url: str, timeout=30):
    hdrs = {
        "User-Agent": UA,
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    }
    r = requests.get(url, headers=hdrs, timeout=timeout)
    r.raise_for_status()
    return r.text

def _parse_table_like(html: str):
    soup = BeautifulSoup(html, "html.parser")

    # 1) legacy <table> path
    table = soup.find("table")
    if table and table.tbody:
        rows = []
        for tr in table.tbody.find_all("tr"):
            tds = tr.find_all("td")
            if len(tds) < 4: 
                continue
            # rank
            rank_txt = tds[0].get_text(strip=True)
            m_rank = re.search(r"\d+", rank_txt or "")
            rank = int(m_rank.group()) if m_rank else None
            # name & symbol (varies by markup)
            name_sym = tds[2].get_text("\n", strip=True).split("\n")
            name = name_sym[0].strip() if name_sym else None
            symbol = name_sym[-1].strip() if name_sym else None
            # slug from link
            a = tds[2].find("a", href=True)
            slug = None
            if a:
                m = re.search(r"/currencies/([^/]+)/", a["href"])
                if m: slug = m.group(1)
            # market cap
            mc_txt = (tds[3].get_text(strip=True) or "").replace("$","").replace(",","")
            try:
                market_cap = float(re.sub(r"[^\d.]", "", mc_txt))
            except Exception:
                market_cap = None
            rows.append({"rank":rank,"name":name,"symbol":symbol,"slug":slug,"market_cap_usd":market_cap})
        df = pd.DataFrame(rows)
        if len(df):
            return df

    # 2) some snapshots render rows as card-like divs
    rows = []
    for row in soup.select("tr, div.cmc-table__table-wrapper-outer tr"):
        tds = row.find_all("td")
        if len(tds) >= 4:
            rank_txt = tds[0].get_text(strip=True)
            m_rank = re.search(r"\d+", rank_txt or "")
            rank = int(m_rank.group()) if m_rank else None
            name_block = tds[2]
            name = name_block.get_text(" ", strip=True)
            # try to split symbol (usually last token)
            symbol = None
            tokens = name.split()
            if tokens:
                symbol = tokens[-1]
            a = name_block.find("a", href=True)
            slug = None
            if a:
                m = re.search(r"/currencies/([^/]+)/", a["href"])
                if m: slug = m.group(1)
            mc_txt = (tds[3].get_text(strip=True) or "").replace("$","").replace(",","")
            try:
                market_cap = float(re.sub(r"[^\d.]", "", mc_txt))
            except Exception:
                market_cap = None
            rows.append({"rank":rank,"name":name,"symbol":symbol,"slug":slug,"market_cap_usd":market_cap})
    if rows:
        return pd.DataFrame(rows)

    return pd.DataFrame()

def fetch_snapshot_any(date: dt.date) -> pd.DataFrame:
    ymd = date.strftime("%Y%m%d")
    live_url = f"https://coinmarketcap.com/historical/{ymd}/"
    wb_url   = f"https://web.archive.org/web/{ymd}/https://coinmarketcap.com/historical/{ymd}/"

    # try live
    try:
        html = _http_get(live_url)
        df = _parse_table_like(html)
        if not df.empty:
            df["source_page"] = "cmc_live"
            return df
    except Exception as e:
        # keep going to wayback
        pass

    # try wayback
    html = _http_get(wb_url)
    df = _parse_table_like(html)
    if not df.empty:
        df["source_page"] = "wayback"
        return df

    raise RuntimeError("Could not parse snapshot from CMC live nor Wayback (DOM changed or page missing).")

def main(start_year: int, end_year: int, sleep_s: float=1.2):
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    for y in range(start_year, end_year+1):
        d = last_sunday_of_dec(y)
        out = RAW_DIR/f"{y}"/f"snapshot_{d:%Y%m%d}.parquet"
        if out.exists():
            print(f"[skip] {out} exists")
            continue
        print(f"[fetch] CMC snapshot {d} -> {out}")
        df = fetch_snapshot_any(d)
        df = df.dropna(subset=["rank"]).sort_values("rank").head(250).reset_index(drop=True)
        df["snapshot_date"] = pd.to_datetime(d)
        out.parent.mkdir(parents=True, exist_ok=True)
        df.to_parquet(out, index=False)
        time.sleep(sleep_s)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start-year", type=int, required=True)
    ap.add_argument("--end-year", type=int, required=True)
    ap.add_argument("--sleep", type=float, default=1.2)
    args = ap.parse_args()
    main(args.start_year, args.end_year, args.sleep)
