#!/usr/bin/env python
"""
Aggregate daily asset files (from Binance or CoinGecko) to weekly OHLCV.
- Prefers data/raw/binance/*.parquet; if none, falls back to data/raw/coingecko/*.parquet.
- Computes weekly simple returns and merges rf_weekly if present.

Output: data/curated/prices_weekly.parquet (long format)

Columns (superset;依來源而定):
- date_week
- market (Binance) / coingecko_id (CoinGecko)
- symbol (Binance)
- open, high, low, close, volume
- ret_simple_weekly
- rf_weekly (if available)
"""
import yaml
from pathlib import Path
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
CFG = yaml.safe_load(open(ROOT/"config/data_sources.yaml"))
RAW = ROOT/CFG["io"]["raw_dir"]
CUR = ROOT/CFG["io"]["curated_dir"]
BOUNDARY = CFG["risk_free"]["weekly_boundary"]

def weekly_aggregate(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # 正規化欄位
    if "date" not in df.columns:
        raise ValueError("daily frame missing 'date' column")

    for col in ["open","high","low","close","volume"]:
        if col not in df.columns:
            df[col] = np.nan

    df["date"] = pd.to_datetime(df["date"])
    df = df.set_index("date").sort_index()

    o = df["open"].resample("W-"+BOUNDARY).first()
    h = df["high"].resample("W-"+BOUNDARY).max()
    l = df["low"].resample("W-"+BOUNDARY).min()
    c = df["close"].resample("W-"+BOUNDARY).last()
    v = df["volume"].resample("W-"+BOUNDARY).sum(min_count=1)

    wf = pd.concat({"open":o, "high":h, "low":l, "close":c, "volume":v}, axis=1)
    wf = wf.dropna(subset=["close"])
    wf = wf.reset_index().rename(columns={"date":"date_week"})
    wf["ret_simple_weekly"] = wf["close"]/wf["close"].shift(1) - 1.0
    wf = wf.dropna(subset=["ret_simple_weekly"])
    return wf

def main():
    CUR.mkdir(parents=True, exist_ok=True)

    # 來源自動偵測：先看 binance，再看 coingecko
    binance_dir = RAW / "binance"
    coingecko_dir = RAW / "coingecko"

    binance_files = sorted(binance_dir.glob("*.parquet")) if binance_dir.exists() else []
    coingecko_files = sorted(coingecko_dir.glob("*.parquet")) if coingecko_dir.exists() else []

    if binance_files:
        source = "binance"
        files = binance_files
    elif coingecko_files:
        source = "coingecko"
        files = coingecko_files
    else:
        raise SystemExit("No raw daily files found in data/raw/binance or data/raw/coingecko.")

    rows = []
    for fp in files:
        df = pd.read_parquet(fp)
        if df.empty:
            continue
        wf = weekly_aggregate(df)

        if source == "binance":
            if "market" in df.columns:
                wf["market"] = df["market"].iloc[0]
            if "symbol" in df.columns:
                wf["symbol"] = df["symbol"].iloc[0]
        else:  # coingecko
            if "coingecko_id" in df.columns:
                wf["coingecko_id"] = df["coingecko_id"].iloc[0]

        rows.append(wf)

    if not rows:
        raise SystemExit("All raw daily files are empty after filtering.")

    allw = pd.concat(rows, ignore_index=True)

    # 併入 rf_weekly（若存在）
    rf_path = CUR/"rf_weekly.parquet"
    if rf_path.exists():
        rf = pd.read_parquet(rf_path)
        allw = allw.merge(rf, on="date_week", how="left")

    allw["data_version"] = pd.Timestamp.utcnow().strftime("%Y%m%d-%H%M")
    out = CUR/"prices_weekly.parquet"
    allw.to_parquet(out, index=False)

    # 簡單回報
    n_assets = (allw["market"].nunique() if "market" in allw.columns
                else allw.get("coingecko_id", pd.Series(dtype=object)).nunique())
    n_weeks = allw["date_week"].nunique()
    print(f"[ok] wrote {out} — assets: {n_assets}, weeks: {n_weeks}, rows: {len(allw):,}")

if __name__ == "__main__":
    main()
