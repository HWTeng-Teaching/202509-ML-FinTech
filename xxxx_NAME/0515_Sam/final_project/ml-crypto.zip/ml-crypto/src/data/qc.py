#!/usr/bin/env python
"""
Data quality report for weekly series (Binance or CoinGecko).
- Auto-detects asset key: market (Binance) / symbol / coingecko_id
- Coverage by asset (first/last week, #weeks)
- Missing rf rows
- Extreme weekly returns flag (|r| > 0.8) by asset
- Flat-price weeks by asset (close_t == close_{t-1})

Outputs JSON under data/metrics/data_quality_report_YYYYMMDD.json
"""
import json, yaml
from pathlib import Path
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
CFG = yaml.safe_load(open(ROOT/"config/data_sources.yaml"))
CUR = ROOT/CFG["io"]["curated_dir"]
MET = ROOT/CFG["io"]["metrics_dir"]

ASSET_KEYS = ["market", "symbol", "coingecko_id"]  # priority order

def pick_asset_key(df: pd.DataFrame) -> str:
    for k in ASSET_KEYS:
        if k in df.columns:
            return k
    # fallback: use a constant (single-asset dataset)
    return None

def main():
    MET.mkdir(parents=True, exist_ok=True)
    pw_path = CUR/"prices_weekly.parquet"
    if not pw_path.exists():
        raise SystemExit(f"Missing {pw_path}. Run weekly_align.py first.")
    pw = pd.read_parquet(pw_path)

    key = pick_asset_key(pw)
    if key is None:
        # no obvious key; consider whole set as one asset
        pw["_asset"] = "asset_0"
        key = "_asset"

    # ensure types
    pw["date_week"] = pd.to_datetime(pw["date_week"])
    if "close" not in pw.columns:
        raise SystemExit("prices_weekly.parquet is missing 'close' column.")

    # coverage
    cov = (
        pw.groupby(key)["date_week"]
          .agg(first_week="min", last_week="max", n_weeks="count")
          .reset_index()
          .rename(columns={key: "asset"})
    )

    # extreme returns
    pw["flag_extreme_ret"] = pw["ret_simple_weekly"].abs() > 0.8
    extreme = (
        pw.groupby(key)["flag_extreme_ret"].sum()
        .astype(int).to_dict()
    )

    # flat price weeks: compute within each asset
    pw = pw.sort_values([key, "date_week"])
    pw["close_prev"] = pw.groupby(key)["close"].shift(1)
    pw["flag_flat"] = (pw["close"] == pw["close_prev"]).fillna(False)
    flat = (
        pw.groupby(key)["flag_flat"].sum()
        .astype(int).to_dict()
    )

    # rf missing
    missing_rf = int(pw["rf_weekly"].isna().sum()) if "rf_weekly" in pw.columns else None

    report = {
        "data_version": pd.Timestamp.utcnow().strftime("%Y%m%d-%H%M"),
        "asset_key": key,
        "summary": {
            "n_assets": int(pw[key].nunique()),
            "n_weeks_total": int(pw["date_week"].nunique()),
            "rows": int(len(pw)),
        },
        "assets": {
            "coverage_by_asset": cov.to_dict(orient="records"),
        },
        "quality": {
            "missing_rf_rows": missing_rf,
            "extreme_return_counts_by_asset": extreme,
            "flat_weeks_counts_by_asset": flat,
        },
    }

    out = MET/f"data_quality_report_{pd.Timestamp.utcnow():%Y%m%d}.json"
    with open(out, "w") as f:
        json.dump(report, f, indent=2, default=str)
    print(f"[ok] wrote {out}")

if __name__ == "__main__":
    main()
