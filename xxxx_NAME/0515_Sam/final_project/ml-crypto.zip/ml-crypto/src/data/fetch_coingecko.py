#!/usr/bin/env python
"""
Robust CoinGecko fetcher for daily OHLC + market cap + volume.

Improvements:
- Auto-resolve coin ids using /coins/list (symbol/name → id mapping).
- Retry with exponential backoff on HTTP 429 (rate limit).
- Skip gracefully on 404 (coin not found) but continue others.

Outputs: data/raw/coingecko/{id}.parquet
"""
import argparse, time, sys, os, yaml, math
from pathlib import Path
import pandas as pd
import requests
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[2]
CFG = yaml.safe_load(open(ROOT/"config/data_sources.yaml"))
RAW = ROOT/CFG["io"]["raw_dir"]
CUR = ROOT/CFG["io"]["curated_dir"]

BASE = CFG["coingecko"]["base_url"]
VS = CFG["coingecko"]["vs_currency"]
SLEEP = float(CFG["coingecko"].get("sleep_seconds_between_calls", 2.5))
HEADERS = {"User-Agent": "ml-crypto/step1 (research)"}

def load_universe_ids(path: Path) -> pd.DataFrame:
    df = pd.read_parquet(path)
    # keep name/symbol for matching
    cols = [c for c in ["year","rank_top30","name","symbol","coingecko_id_guess"] if c in df.columns]
    return df[cols].copy()

def get_all_coin_list() -> pd.DataFrame:
    url = f"{BASE}/coins/list"
    r = requests.get(url, headers=HEADERS, timeout=60)
    r.raise_for_status()
    df = pd.DataFrame(r.json())
    # normalize
    for c in ["id","symbol","name"]:
        if c not in df.columns: df[c] = ""
    df["symbol_u"] = df["symbol"].astype(str).str.lower()
    df["name_u"]   = df["name"].astype(str).str.lower()
    return df

def resolve_id(row, coinlist: pd.DataFrame):
    # priority: exact id match → symbol match → name match
    guess = str(row.get("coingecko_id_guess","") or "").strip().lower()
    sym   = str(row.get("symbol","") or "").strip().lower()
    name  = str(row.get("name","") or "").strip().lower()
    # exact id
    if guess and (coinlist["id"] == guess).any():
        return guess
    # symbol (prefer the most common, but symbol may be ambiguous; choose first)
    if sym:
        matches = coinlist[coinlist["symbol_u"] == sym]
        if len(matches) >= 1:
            return matches.iloc[0]["id"]
    # name
    if name:
        matches = coinlist[coinlist["name_u"] == name]
        if len(matches) >= 1:
            return matches.iloc[0]["id"]
    # last resort: keep guess (even if invalid) to log 404 later
    return guess if guess else None

def backoff_sleep(attempt: int):
    # attempt starts at 1 → sleep min( 2^(attempt)+jitter , 90s )
    jitter = 0.3 * attempt
    wait = min((2 ** attempt) + jitter, 90.0)
    time.sleep(wait)

def req_json(url, params):
    attempt = 0
    while True:
        try:
            r = requests.get(url, params=params, headers=HEADERS, timeout=90)
            if r.status_code == 429:
                attempt += 1
                backoff_sleep(attempt)
                continue
            r.raise_for_status()
            return r.json()
        except requests.HTTPError as e:
            if r.status_code == 404:
                return {"__404__": True}
            attempt += 1
            if attempt >= 5:
                raise
            backoff_sleep(attempt)

def get_ohlc(coin_id: str) -> pd.DataFrame:
    url = f"{BASE}/coins/{coin_id}/ohlc"
    data = req_json(url, {"vs_currency": VS, "days": "max"})
    if isinstance(data, dict) and data.get("__404__"):
        return pd.DataFrame(), True
    if not data:
        return pd.DataFrame(), False
    df = pd.DataFrame(data, columns=["ts","open","high","low","close"])
    df["date"] = pd.to_datetime(df["ts"], unit="ms").dt.tz_localize("UTC").dt.date
    df = df.drop(columns=["ts"]).drop_duplicates(subset=["date"]).sort_values("date")
    return df, False

def get_market_chart(coin_id: str) -> pd.DataFrame:
    url = f"{BASE}/coins/{coin_id}/market_chart"
    data = req_json(url, {"vs_currency": VS, "days": "max"})
    if isinstance(data, dict) and data.get("__404__"):
        return pd.DataFrame(), True
    def to_df(key, colname):
        arr = data.get(key, [])
        if not arr: return pd.DataFrame(columns=["date", colname])
        df = pd.DataFrame(arr, columns=["ts","val"])
        df["date"] = pd.to_datetime(df["ts"], unit="ms").dt.tz_localize("UTC").dt.date
        df = df.drop(columns=["ts"]).rename(columns={"val": colname})
        return df
    p = to_df("prices", "price_close")
    m = to_df("market_caps", "market_cap_usd")
    v = to_df("total_volumes", "volume_usd")
    df = p.merge(m, on="date", how="outer").merge(v, on="date", how="outer").sort_values("date")
    return df, False

def merge_frames(ohlc: pd.DataFrame, mc: pd.DataFrame) -> pd.DataFrame:
    if ohlc.empty and mc.empty:
        return pd.DataFrame()
    if ohlc.empty:
        df = mc.rename(columns={"price_close": "close"})
        df["open"]=df["high"]=df["low"]=pd.NA
        return df
    if mc.empty:
        df = ohlc.copy()
        df["market_cap_usd"]=df["volume_usd"]=pd.NA
        return df
    df = ohlc.merge(mc, on="date", how="outer").sort_values("date")
    if "price_close" in df.columns:
        df["close"] = df["close"].fillna(df["price_close"])
        df = df.drop(columns=["price_close"])
    return df

def fetch_one(coin_id: str, outdir: Path):
    outfp = outdir/f"{coin_id}.parquet"
    if outfp.exists():
        return "skip"
    # respectful initial sleep
    time.sleep(SLEEP)
    ohlc, o404a = get_ohlc(coin_id)
    time.sleep(SLEEP)
    mc,   o404b = get_market_chart(coin_id)
    if o404a and o404b:
        return "404"
    df = merge_frames(ohlc, mc)
    if df.empty:
        return "empty"
    df["coingecko_id"]=coin_id
    df["date"] = pd.to_datetime(df["date"])
    df["data_version"]=pd.Timestamp.utcnow().strftime("%Y%m%d-%H%M")
    df.to_parquet(outfp, index=False)
    return "ok"

def main(universe_path, ids, start, end):
    outdir = RAW/"coingecko"
    outdir.mkdir(parents=True, exist_ok=True)

    # load universe and resolve ids
    if universe_path:
        uni = load_universe_ids(Path(universe_path))
        coinlist = get_all_coin_list()
        uni["resolved_id"] = uni.apply(lambda r: resolve_id(r, coinlist), axis=1)
        # 去掉解析不到的，避免 404 轟炸；你可在 config/universe.yaml 增補映射再跑一次
        todo = sorted(set(uni["resolved_id"].dropna().astype(str)))
    else:
        todo = ids or []
    if not todo:
        raise SystemExit("No coin ids resolved (check universe or ids).")

    results = {}
    for cid in tqdm(todo, desc="coingecko"):
        try:
            status = fetch_one(cid, outdir)
        except Exception as e:
            status = f"error: {e}"
        results[cid]=status

    print(results)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--universe", type=str, help="path to universe_top30_annual.parquet")
    ap.add_argument("--ids", nargs="*")
    ap.add_argument("--start", type=str, default=None)
    ap.add_argument("--end", type=str, default=None)
    args = ap.parse_args()
    main(args.universe, args.ids, args.start, args.end)
