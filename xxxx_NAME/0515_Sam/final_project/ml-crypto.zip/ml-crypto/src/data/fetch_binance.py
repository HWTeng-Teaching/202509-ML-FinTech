#!/usr/bin/env python
"""
Fetch daily OHLCV from Binance spot for a given universe (Top-30 by year).
- Maps each universe symbol to a Binance market (default: SYMBOL/USDT).
- Falls back to SYMBOL/USDC if USDT pair not found.
- Allows manual overrides in config/universe.yaml -> symbol_to_binance_pair.
- Saves per-asset daily parquet under data/raw/binance/{binance_symbol}.parquet

Columns: date, open, high, low, close, volume (base volume), market (e.g., BTC/USDT), symbol (universe symbol)
Note: Binance不提供市值；weekly_align 會自動容許沒有 market_cap。

Usage:
  python src/data/fetch_binance.py --universe data/curated/universe_top30_annual.parquet --start 2016-01-01 --end 2025-12-31
"""
import argparse, os, math, time, json
from pathlib import Path
import pandas as pd
import ccxt
import yaml
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
CFG  = yaml.safe_load(open(ROOT/"config/data_sources.yaml"))
UNI  = yaml.safe_load(open(ROOT/"config/universe.yaml")) or {}

RAW  = ROOT/CFG["io"]["raw_dir"]
RAW_BIN = RAW/"binance"
RAW_BIN.mkdir(parents=True, exist_ok=True)

def load_universe(path: Path) -> pd.DataFrame:
    df = pd.read_parquet(path)
    # 去重（同年同symbol）
    if "year" in df.columns and "symbol" in df.columns:
        df = df.drop_duplicates(subset=["year","symbol"])
    return df

def symbol_to_market(symbol: str, markets: dict, overrides: dict) -> str | None:
    # 1) 覆寫：config/universe.yaml:symbol_to_binance_pair
    pair = (overrides or {}).get(symbol.upper())
    if pair and pair in markets:
        return pair
    # 2) 假設 USDT 交易對
    guess = f"{symbol.upper()}/USDT"
    if guess in markets: 
        return guess
    # 3) fallback USDC
    guess2 = f"{symbol.upper()}/USDC"
    if guess2 in markets:
        return guess2
    # 4) 常見別名修正（例：MIOTA 在 Binance 是 IOTA）
    alias = {
        "MIOTA": "IOTA",
        "BCC": "BCH",        # 老稱呼
        "XBT": "BTC",
    }
    if symbol.upper() in alias:
        s2 = alias[symbol.upper()]
        for q in ("USDT","USDC"):
            c = f"{s2}/{q}"
            if c in markets:
                return c
    return None

def fetch_ohlcv_all(exchange: ccxt.Exchange, market: str, start_ts: int, end_ts: int, tf="1d", limit=1000):
    """
    拉取完整日期區間的日K；Binance單次最多1000根K線，loop到結束。
    """
    out = []
    since = start_ts
    while True:
        data = exchange.fetch_ohlcv(market, timeframe=tf, since=since, limit=limit)
        if not data:
            break
        out.extend(data)
        last_ts = data[-1][0]
        # 下個窗口從最後一根K線時間+1ms開始
        next_since = last_ts + 1
        if next_since >= end_ts:
            break
        # Binance 有頻率限制；ccxt enableRateLimit=True會自動sleep，這裡小等一會兒更穩
        time.sleep(0.2)
        since = next_since
    return out

def main(universe_path, start, end):
    uni = load_universe(Path(universe_path))
    # 取「每年Top30」的符號集合
    symbols = sorted(set(uni["symbol"].astype(str).str.upper()))
    overrides = (UNI or {}).get("symbol_to_binance_pair", {}) or {}

    # 準備 exchange
    exchange = ccxt.binance({"enableRateLimit": True})
    markets = exchange.load_markets()
    start_ts = int(pd.Timestamp(start, tz="UTC").timestamp() * 1000) if start else None
    end_ts   = int(pd.Timestamp(end,   tz="UTC").timestamp() * 1000) if end   else int(pd.Timestamp.utcnow().timestamp()*1000)

    # 逐幣抓取
    results = {}
    for sym in symbols:
        market = symbol_to_market(sym, markets, overrides)
        if not market:
            results[sym] = "no_market"
            continue
        # 檔名用市場代碼，如 BTCUSDT -> BTCUSDT.parquet
        out_sym = market.replace("/", "")
        outfp = RAW_BIN/f"{out_sym}.parquet"
        if outfp.exists():
            results[sym] = "skip"
            continue

        try:
            data = fetch_ohlcv_all(exchange, market, start_ts, end_ts, tf="1d", limit=1000)
            if not data:
                results[sym] = "empty"
                continue
            # ccxt ohlcv: [timestamp, open, high, low, close, volume]
            df = pd.DataFrame(data, columns=["ts","open","high","low","close","volume"])
            df["date"] = pd.to_datetime(df["ts"], unit="ms", utc=True).dt.tz_convert("UTC").dt.date
            df = df.drop(columns=["ts"]).drop_duplicates(subset=["date"]).sort_values("date")
            df["market"] = market
            df["symbol"] = sym
            df["data_version"] = pd.Timestamp.utcnow().strftime("%Y%m%d-%H%M")
            df.to_parquet(outfp, index=False)
            results[sym] = "ok"
        except Exception as e:
            results[sym] = f"error: {e}"

    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--universe", type=str, required=True, help="path to universe_top30_annual.parquet")
    ap.add_argument("--start", type=str, default="2016-01-01")
    ap.add_argument("--end", type=str, default=None)
    args = ap.parse_args()
    main(args.universe, args.start, args.end)
