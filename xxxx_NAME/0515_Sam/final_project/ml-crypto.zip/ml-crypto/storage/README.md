# Storage strategy

- **Raw** (`data/raw/`): append-only; never overwrite past pulls.
- **Curated** (`data/curated/`): deterministic outputs of pipeline steps with schema contracts.
- **Metrics** (`data/metrics/`): data-health & QC reports as JSON for diffs in PRs.
- Use `data_version` (YYYYMMDD-HHMM) in Parquet metadata to reproduce runs.

For cloud, keep the same folder hierarchy in an object store (e.g., `s3://bucket/ml-crypto/`).