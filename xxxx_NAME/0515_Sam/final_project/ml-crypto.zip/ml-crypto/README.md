ml-crypto/
├─ config/
│   ├─ data_sources.yaml           # API keys & data settings (e.g., FRED)
│   └─ universe.yaml               # Symbol → Binance pair overrides
├─ data/
│   ├─ raw/
│   │   ├─ binance/*.parquet       # Daily OHLCV per asset from Binance
│   │   └─ cmc/YYYY/snapshot_*.parquet   # Year-end CMC snapshots (universe)
│   ├─ curated/
│   │   ├─ prices_weekly.parquet         # Weekly OHLCV + returns + rf
│   │   ├─ universe_top30_annual.parquet
│   │   ├─ factors_weekly.parquet        # Weekly features (cross-sec z-scores)
│   │   ├─ fmp_weekly.parquet            # Factor-mimicking ports (CMKT/…)
│   │   ├─ ml_preds_weekly.parquet       # ML predictions per week/asset
│   │   └─ backtest_ml_longshort.parquet # Backtest weekly series
│   └─ metrics/
│       ├─ data_quality_report_*.json
│       ├─ ml_train_logs_*.json
│       ├─ ml_feature_importance_*.csv
│       └─ backtest_summary_*.json
├─ notebooks/
│   ├─ factor_eda.ipynb            # Feature EDA / correlations / PCA
│   ├─ fama_macbeth.ipynb          # Fama–MacBeth with HAC/Newey–West
│   ├─ factor_model.ipynb          # 3-factor regressions, alpha/exposures
│   ├─ ml_train.ipynb              # ML training (cross-sectional ranking)
│   └─ portfolio_backtest.ipynb    # Backtest + risk controls
├─ scripts/
│   └─ make_data.sh                # One-shot data build (Step 1)
└─ src/
    ├─ data/
    │   ├─ fetch_cmc.py            # CMC year-end snapshots (for annual Top-30)
    │   ├─ build_universe.py       # Assemble annual Top-30 (ex-stables)
    │   ├─ fetch_binance.py        # Daily OHLCV via Binance (USDT/USDC)
    │   ├─ fetch_fred.py           # FRED 4W T-Bill → weekly rf
    │   ├─ weekly_align.py         # Daily→weekly (Sun close), merge rf
    │   └─ qc.py                   # Coverage & quality report
    └─ features/
        ├─ build_factors_v2.py     # Literature-backed weekly features
        └─ build_fmp.py            # Factor-mimicking portfolios


ml-crypto/
├─ config/
│   ├─ data_sources.yaml           # 資料來源/參數（如 API key、對應表）
│   └─ universe.yaml               # 代號對應與手動 override（Binance 交易對等）
├─ data/
│   ├─ raw/                        # 原始抓取（日頻）
│   │   ├─ binance/*.parquet       # 各資產日 OHLCV（自 Binance）
│   │   └─ cmc/YYYY/snapshot_*.parquet # CMC 年末快照（決定年度 Top30 宇宙）
│   ├─ curated/                    # 清理後（週頻）與衍生資料
│   │   ├─ prices_weekly.parquet   # 週 OHLCV + ret_simple_weekly + rf（若有）
│   │   ├─ universe_top30_annual.parquet
│   │   ├─ factors_weekly.parquet  # 週頻特徵（z-score）
│   │   ├─ fmp_weekly.parquet      # 因子模擬組合（CMKT/CSMB/CMOM）
│   │   ├─ ml_preds_weekly.parquet # ML 產生的每週橫截面預測分數與標籤
│   │   └─ backtest_ml_longshort.parquet # 回測逐週明細
│   └─ metrics/
│       ├─ data_quality_report_*.json
│       ├─ ml_train_logs_*.json
│       ├─ ml_feature_importance_*.csv
│       └─ backtest_summary_*.json
├─ notebooks/
│   ├─ factor_eda.ipynb            # 特徵 EDA / 相關性 / PCA
│   ├─ fama_macbeth.ipynb          # Fama–MacBeth 檢定（HAC/NW）
│   ├─ factor_model.ipynb          # 三因子/多因子回歸（檢 α、曝險）
│   ├─ ml_train.ipynb              # 機器學習訓練（橫截面排序）
│   └─ portfolio_backtest.ipynb    # 回測 + 風控（β-neutral / vol targeting / 成本）
├─ scripts/
│   └─ make_data.sh                # 一鍵執行 Step 1（資料→週頻對齊）
└─ src/
    ├─ data/
    │   ├─ fetch_cmc.py            # CMC 年末快照（用以建立年度 Top30）
    │   ├─ build_universe.py       # 組合年度 Top30 宇宙（排除穩定幣）
    │   ├─ fetch_binance.py        # 從 Binance 下載日 OHLCV（USDT/USDC 配對）
    │   ├─ fetch_fred.py           # FRED 4W T-Bill 週頻（風險自由利率）
    │   ├─ weekly_align.py         # 聚合日頻到週頻（週日收），合併 rf
    │   └─ qc.py                   # 資料涵蓋度/完整性檢查報告
    └─ features/
        ├─ build_factors_v2.py     # 依文獻可行且穩健的週頻特徵
        └─ build_fmp.py            # 因子模擬組合（CMKT/CSMB/CMOM）

# quickstart
# 0) Environment
conda activate crypto_env
pip install -r requirements.txt

# 1) Data → weekly
bash scripts/make_data.sh 2016 2024 2016-01-01 2025-12-31

# 2) Features
python src/features/build_factors_v2.py

# 3) Factor-mimicking portfolios
python src/features/build_fmp.py

# 4) (Optional) EDA & tests in notebooks

# 5) ML ranking (produces ml_preds_weekly.parquet)
# open notebooks/ml_train.ipynb and run cells

# 6) Backtest + risk controls (produces backtest + summary)
# open notebooks/portfolio_backtest.ipynb and run cells
